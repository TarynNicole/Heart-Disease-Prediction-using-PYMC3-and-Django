from django import forms

class InputForm(forms.Form):
    age = forms.DecimalField(min_value=0)
    Sex = forms.DecimalField(min_value=0)
    cp_value = forms.DecimalField(min_value=0)
    trestbps = forms.DecimalField(min_value=0)
    chol = forms.DecimalField(min_value=0)
    fbs = forms.DecimalField(min_value=0)
    restecg_value = forms.DecimalField(min_value=0)
    thalach_value = forms.DecimalField(min_value=0)
    exang_value = forms.DecimalField(min_value=0)
    oldpeak_value = forms.DecimalField(min_value=0)
    slope_value = forms.DecimalField(min_value=0)
    ca_value = forms.DecimalField(min_value=0)
    thal_value = forms.DecimalField(min_value=0)
    
