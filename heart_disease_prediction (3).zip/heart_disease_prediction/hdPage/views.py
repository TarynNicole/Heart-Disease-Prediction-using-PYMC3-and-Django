from django.shortcuts import render
from django.http import HttpResponse
from .forms import InputForm
import pandas as pd
import numpy as np
import pickle
import pymc3 as pm



# Create your views here.


# Loading Probabilistic Model
with open('./models/heart_disease_model.pkl', 'rb') as buff:
    PMLmodel = pickle.load(buff)

# Obtaining Model and Model trace from loaded Probabilistic Model
PML_loadModel, PML_trace = PMLmodel['model'], PMLmodel['trace']

def index(request):
    if request.method == "POST":
        myform = InputForm(request.POST)
        if myform.is_valid():
            age = myform.cleaned_data['age']
            sex = myform.cleaned_data['sex']
            cp = myform.cleaned_data['cp_value']
            trestbps = myform.cleaned_data['trestbps']
            chol = myform.cleaned_data['chol']
            fbs = myform.cleaned_data['fbs']
            restecg = myform.cleaned_data['restecg_value']
            thalach = myform.cleaned_data['thalach_value']
            exang = myform.cleaned_data['exang_value']
            oldpeak = myform.cleaned_data['oldpeak_value']
            slope = myform.cleaned_data['slope_value']
            ca = myform.cleaned_data['ca']
            thal = myform.cleaned_data['thal_value']
         
            _inputs = [[age, sex, cp, trestbps, chol, fbs, restecg,thalach, exang, oldpeak, slope, ca,  thal]]
            target = PMLmodel['model'].predict(_inputs)
            return render(request, 'index.html', {'prediction': target})
    else:
        myform = InputForm()

    return render(request, 'index.html', {'form': myform})
